package util;


import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.test.annotations.WrapToTest;
 
import java.io.File;
import java.io.IOException;
/**
 * Simple Hello World example.
 */
@WrapToTest
public class GeraPDFUtil {
 
    public static final String DEST = "c:/a/filipe.pdf";
 
    public static void geraPDF() throws IOException {
        File file = new File(DEST);
        file.getParentFile().mkdirs();
        new GeraPDFUtil().createPdf(DEST);
    }
 
    public void createPdf(String dest) throws IOException {
        //Initialize PDF writer
        PdfWriter writer = new PdfWriter(dest);
 
        //Initialize PDF document
        PdfDocument pdf = new PdfDocument(writer);
 
        // Initialize document
        Document document = new Document(pdf);
 
        //Add paragraph to the document
        document.add(new Paragraph("Hello Felipe!!!!!!!"));
 
        //Close document
        document.close();
    }
}